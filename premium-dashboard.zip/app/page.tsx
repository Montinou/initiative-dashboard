"use client"
import PremiumDashboard from "../dashboard"

export default function Page() {
  return <PremiumDashboard />
}
